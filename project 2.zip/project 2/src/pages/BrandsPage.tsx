import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Star, Award, Leaf } from 'lucide-react';

const BrandsPage = () => {
  const brands = [
    {
      id: 1,
      name: 'EcoSmile',
      logo: 'https://images.pexels.com/photos/6621464/pexels-photo-6621464.jpeg?auto=compress&cs=tinysrgb&w=200',
      description: 'Sustainable oral care products made from bamboo and natural ingredients',
      products: 15,
      rating: 4.8,
      category: 'Personal Care',
      established: '2018',
      certifications: ['Organic', 'Cruelty-Free', 'Vegan']
    },
    {
      id: 2,
      name: 'GreenHome',
      logo: 'https://images.pexels.com/photos/6207833/pexels-photo-6207833.jpeg?auto=compress&cs=tinysrgb&w=200',
      description: 'Eco-friendly home essentials and reusable products for sustainable living',
      products: 28,
      rating: 4.9,
      category: 'Home & Living',
      established: '2016',
      certifications: ['Fair Trade', 'Organic', 'Recycled Materials']
    },
    {
      id: 3,
      name: 'NaturalCare',
      logo: 'https://images.pexels.com/photos/4202325/pexels-photo-4202325.jpeg?auto=compress&cs=tinysrgb&w=200',
      description: 'Handmade soaps and skincare products using traditional methods',
      products: 22,
      rating: 4.7,
      category: 'Personal Care',
      established: '2019',
      certifications: ['Handmade', 'Natural', 'Chemical-Free']
    },
    {
      id: 4,
      name: 'EcoWear',
      logo: 'https://images.pexels.com/photos/7679720/pexels-photo-7679720.jpeg?auto=compress&cs=tinysrgb&w=200',
      description: 'Sustainable fashion made from organic cotton and recycled materials',
      products: 35,
      rating: 4.6,
      category: 'Fashion',
      established: '2017',
      certifications: ['GOTS Certified', 'Fair Trade', 'Organic']
    },
    {
      id: 5,
      name: 'TeaGarden',
      logo: 'https://images.pexels.com/photos/1389104/pexels-photo-1389104.jpeg?auto=compress&cs=tinysrgb&w=200',
      description: 'Premium organic teas sourced directly from sustainable tea gardens',
      products: 18,
      rating: 4.8,
      category: 'Wellness',
      established: '2015',
      certifications: ['Organic', 'Fair Trade', 'Rainforest Alliance']
    },
    {
      id: 6,
      name: 'WoodCraft',
      logo: 'https://images.pexels.com/photos/6207833/pexels-photo-6207833.jpeg?auto=compress&cs=tinysrgb&w=200',
      description: 'Handcrafted wooden products made from sustainably sourced wood',
      products: 12,
      rating: 4.9,
      category: 'Home & Living',
      established: '2020',
      certifications: ['FSC Certified', 'Handmade', 'Sustainable Wood']
    },
    {
      id: 7,
      name: 'ZenYoga',
      logo: 'https://images.pexels.com/photos/3766227/pexels-photo-3766227.jpeg?auto=compress&cs=tinysrgb&w=200',
      description: 'Eco-friendly yoga and wellness products for mindful living',
      products: 14,
      rating: 4.7,
      category: 'Wellness',
      established: '2018',
      certifications: ['Eco-Friendly', 'Non-Toxic', 'Sustainable']
    },
    {
      id: 8,
      name: 'PureGlow',
      logo: 'https://images.pexels.com/photos/7656738/pexels-photo-7656738.jpeg?auto=compress&cs=tinysrgb&w=200',
      description: 'Natural skincare products with ayurvedic ingredients',
      products: 20,
      rating: 4.6,
      category: 'Personal Care',
      established: '2019',
      certifications: ['Ayurvedic', 'Natural', 'Paraben-Free']
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center space-x-4 mb-4">
            <Link 
              to="/" 
              className="flex items-center text-emerald-600 hover:text-emerald-700 transition-colors"
            >
              <ArrowLeft className="h-5 w-5 mr-2" />
              Back to Home
            </Link>
          </div>
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
            <div>
              <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-2">
                Our Trusted Brands
              </h1>
              <p className="text-lg text-gray-600 max-w-2xl">
                Discover brands that share our commitment to sustainability, quality, and ethical practices.
              </p>
            </div>
            <div className="mt-4 lg:mt-0 text-sm text-gray-500">
              {brands.length} trusted partners
            </div>
          </div>
        </div>
      </div>

      {/* Brands Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {brands.map((brand) => (
            <div
              key={brand.id}
              className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 group cursor-pointer"
            >
              <div className="aspect-[16/9] overflow-hidden">
                <img
                  src={brand.logo}
                  alt={brand.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              
              <div className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-xl font-bold text-gray-900 group-hover:text-emerald-600 transition-colors">
                    {brand.name}
                  </h3>
                  <div className="flex items-center space-x-1">
                    <Star className="h-4 w-4 text-yellow-400 fill-current" />
                    <span className="text-sm font-medium text-gray-600">{brand.rating}</span>
                  </div>
                </div>
                
                <p className="text-gray-600 mb-4 line-clamp-3">
                  {brand.description}
                </p>
                
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500">Products:</span>
                    <span className="font-medium text-gray-900">{brand.products}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500">Category:</span>
                    <span className="font-medium text-emerald-600">{brand.category}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500">Since:</span>
                    <span className="font-medium text-gray-900">{brand.established}</span>
                  </div>
                </div>
                
                <div className="mt-4 pt-4 border-t border-gray-100">
                  <div className="flex flex-wrap gap-2">
                    {brand.certifications.map((cert, index) => (
                      <span
                        key={index}
                        className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-emerald-100 text-emerald-800"
                      >
                        <Award className="h-3 w-3 mr-1" />
                        {cert}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Call to Action */}
      <div className="bg-emerald-600 py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Leaf className="h-12 w-12 text-emerald-200 mx-auto mb-6" />
          <h2 className="text-3xl font-bold text-white mb-4">
            Partner With Us
          </h2>
          <p className="text-emerald-100 text-lg mb-8">
            Are you a sustainable brand looking to reach conscious consumers? 
            Join our community of trusted partners.
          </p>
          <button className="bg-white text-emerald-600 px-8 py-3 rounded-full font-semibold hover:bg-gray-50 transition-colors duration-200">
            Become a Partner
          </button>
        </div>
      </div>
    </div>
  );
};

export default BrandsPage;