import React, { useState } from 'react';
import { Mail, Check } from 'lucide-react';

const Newsletter = () => {
  const [email, setEmail] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setIsSubscribed(true);
      setEmail('');
      setTimeout(() => setIsSubscribed(false), 3000);
    }
  };

  return (
    <section className="py-16 bg-emerald-600">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="space-y-8">
          <div>
            <h2 className="text-3xl lg:text-4xl font-bold text-white mb-4">
              Stay Updated with Sustainable Living Tips
            </h2>
            <p className="text-emerald-100 text-lg">
              Get weekly eco-friendly tips, exclusive offers, and new product updates delivered to your inbox
            </p>
          </div>

          <form onSubmit={handleSubmit} className="max-w-md mx-auto">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1 relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email"
                  className="w-full pl-10 pr-4 py-3 rounded-full border-0 focus:ring-2 focus:ring-white focus:outline-none"
                  required
                />
              </div>
              <button
                type="submit"
                className="bg-white text-emerald-600 px-8 py-3 rounded-full font-semibold hover:bg-gray-50 transition-colors duration-200 flex items-center justify-center"
                disabled={isSubscribed}
              >
                {isSubscribed ? (
                  <>
                    <Check className="h-5 w-5 mr-2" />
                    Subscribed!
                  </>
                ) : (
                  'Subscribe'
                )}
              </button>
            </div>
          </form>

          <div className="flex flex-wrap justify-center gap-8 pt-8">
            <div className="text-center">
              <div className="text-2xl font-bold text-white">10,000+</div>
              <div className="text-emerald-100 text-sm">Newsletter Subscribers</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-white">Weekly</div>
              <div className="text-emerald-100 text-sm">Eco Tips & Updates</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-white">Exclusive</div>
              <div className="text-emerald-100 text-sm">Offers & Discounts</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Newsletter;