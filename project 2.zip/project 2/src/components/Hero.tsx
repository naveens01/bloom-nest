import React from 'react';
import { ArrowRight, Leaf, Recycle, Globe } from 'lucide-react';

const Hero = () => {
  return (
    <section className="relative bg-gradient-to-br from-emerald-50 via-white to-amber-50 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left content */}
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-4xl lg:text-6xl font-bold text-gray-900 leading-tight">
                Sustainable
                <span className="text-emerald-600 block">Living Made</span>
                Beautiful
              </h1>
              <p className="text-lg text-gray-600 max-w-lg">
                Discover eco-friendly products that don't compromise on style or quality. 
                Join thousands making conscious choices for a better planet.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <button className="bg-emerald-600 text-white px-8 py-3 rounded-full font-semibold hover:bg-emerald-700 transition-colors duration-200 flex items-center justify-center group">
                Shop Now
                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </button>
              <button className="border border-emerald-600 text-emerald-600 px-8 py-3 rounded-full font-semibold hover:bg-emerald-50 transition-colors duration-200">
                Learn More
              </button>
            </div>

            {/* Features */}
            <div className="flex flex-wrap gap-6 pt-8">
              <div className="flex items-center space-x-2">
                <Leaf className="h-5 w-5 text-emerald-600" />
                <span className="text-sm font-medium text-gray-700">100% Natural</span>
              </div>
              <div className="flex items-center space-x-2">
                <Recycle className="h-5 w-5 text-emerald-600" />
                <span className="text-sm font-medium text-gray-700">Zero Waste</span>
              </div>
              <div className="flex items-center space-x-2">
                <Globe className="h-5 w-5 text-emerald-600" />
                <span className="text-sm font-medium text-gray-700">Ethically Sourced</span>
              </div>
            </div>
          </div>

          {/* Right content - Hero image placeholder */}
          <div className="relative">
            <div className="aspect-square bg-gradient-to-br from-emerald-100 to-amber-100 rounded-2xl overflow-hidden">
              <img
                src="https://images.pexels.com/photos/6621334/pexels-photo-6621334.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Sustainable products"
                className="w-full h-full object-cover"
              />
            </div>
            {/* Floating elements */}
            <div className="absolute -top-4 -right-4 bg-white p-4 rounded-xl shadow-lg">
              <div className="text-center">
                <p className="text-2xl font-bold text-emerald-600">50K+</p>
                <p className="text-xs text-gray-600">Happy Customers</p>
              </div>
            </div>
            <div className="absolute -bottom-4 -left-4 bg-white p-4 rounded-xl shadow-lg">
              <div className="text-center">
                <p className="text-2xl font-bold text-amber-600">1000+</p>
                <p className="text-xs text-gray-600">Eco Products</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;