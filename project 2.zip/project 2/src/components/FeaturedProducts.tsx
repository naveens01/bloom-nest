import React from 'react';
import { Star, Heart, ShoppingCart } from 'lucide-react';
import { getFeaturedProducts } from '../data/products';
import ProductCard from './ProductCard';

const FeaturedProducts = () => {
  const products = getFeaturedProducts();

  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
            Featured Products
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Hand-picked sustainable products loved by our community
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>

        <div className="text-center mt-12">
          <button className="bg-emerald-600 text-white px-8 py-3 rounded-full font-semibold hover:bg-emerald-700 transition-colors duration-200">
            View All Products
          </button>
        </div>
      </div>
    </section>
  );
};

export default FeaturedProducts;