import React from 'react';
import { Leaf, Award, Users, Globe } from 'lucide-react';

const AboutSection = () => {
  const stats = [
    { icon: Users, number: '50,000+', label: 'Happy Customers' },
    { icon: Leaf, number: '1,000+', label: 'Eco Products' },
    { icon: Award, number: '100+', label: 'Trusted Brands' },
    { icon: Globe, number: '500+', label: 'Cities Served' }
  ];

  const features = [
    {
      title: 'Curated Selection',
      description: 'Every product is carefully vetted for sustainability and quality standards.',
      icon: Award
    },
    {
      title: 'Zero Waste Mission',
      description: 'Plastic-free packaging and carbon-neutral shipping options.',
      icon: Leaf
    },
    {
      title: 'Fair Trade',
      description: 'Supporting artisans and farmers with fair wages and ethical practices.',
      icon: Users
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main content */}
        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          <div className="space-y-8">
            <div>
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-6">
                Building a Sustainable Future, One Product at a Time
              </h2>
              <p className="text-lg text-gray-600 mb-6">
                Brown Living is India's largest sustainable living platform, curating eco-friendly 
                products that help you make conscious choices for a better planet. We believe 
                sustainability shouldn't come at the cost of convenience or style.
              </p>
              <p className="text-gray-600">
                From organic personal care to zero-waste home essentials, every product tells a 
                story of environmental consciousness and social responsibility.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-6">
              {stats.map((stat, index) => (
                <div key={index} className="text-center p-4 bg-gray-50 rounded-xl">
                  <stat.icon className="h-8 w-8 text-emerald-600 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-gray-900">{stat.number}</div>
                  <div className="text-sm text-gray-600">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="relative">
            <img
              src="https://images.pexels.com/photos/3622517/pexels-photo-3622517.jpeg?auto=compress&cs=tinysrgb&w=800"
              alt="Sustainable living"
              className="rounded-2xl w-full h-96 object-cover"
            />
          </div>
        </div>

        {/* Features */}
        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="text-center p-8 bg-gray-50 rounded-2xl">
              <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <feature.icon className="h-8 w-8 text-emerald-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default AboutSection;