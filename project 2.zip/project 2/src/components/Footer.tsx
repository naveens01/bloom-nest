import React from 'react';
import { Facebook, Instagram, Twitter, Youtube, Mail, Phone, MapPin } from 'lucide-react';

const Footer = () => {
  const footerSections = [
    {
      title: 'Categories',
      links: [
        'Personal Care',
        'Home & Living',
        'Fashion',
        'Food & Beverages',
        'Wellness',
        'Baby & Kids'
      ]
    },
    {
      title: 'Information',
      links: [
        'About Us',
        'Sustainability',
        'Blog',
        'Press',
        'Careers',
        'Affiliate Program'
      ]
    },
    {
      title: 'Customer Care',
      links: [
        'Contact Us',
        'FAQ',
        'Shipping Info',
        'Returns & Exchanges',
        'Size Guide',
        'Track Order'
      ]
    },
    {
      title: 'Policies',
      links: [
        'Privacy Policy',
        'Terms & Conditions',
        'Return Policy',
        'Shipping Policy',
        'Cookie Policy',
        'Disclaimer'
      ]
    }
  ];

  const socialLinks = [
    { icon: Facebook, href: '#', label: 'Facebook' },
    { icon: Instagram, href: '#', label: 'Instagram' },
    { icon: Twitter, href: '#', label: 'Twitter' },
    { icon: Youtube, href: '#', label: 'YouTube' }
  ];

  return (
    <footer className="bg-gray-900 text-white">
      {/* Main footer content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-8">
          {/* Brand section */}
          <div className="lg:col-span-2 space-y-6">
            <div>
              <h3 className="text-2xl font-bold text-emerald-400 mb-2">Brown Living</h3>
              <p className="text-gray-300 text-sm mb-4">
                India's largest sustainable living platform. Making eco-friendly living accessible, 
                affordable, and beautiful.
              </p>
            </div>
            
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Mail className="h-4 w-4 text-emerald-400" />
                <span className="text-sm text-gray-300">hello@brownliving.in</span>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="h-4 w-4 text-emerald-400" />
                <span className="text-sm text-gray-300">+91 98765 43210</span>
              </div>
              <div className="flex items-center space-x-3">
                <MapPin className="h-4 w-4 text-emerald-400" />
                <span className="text-sm text-gray-300">Mumbai, India</span>
              </div>
            </div>

            <div className="flex space-x-4">
              {socialLinks.map((social, index) => (
                <a
                  key={index}
                  href={social.href}
                  className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-emerald-600 transition-colors duration-200"
                  aria-label={social.label}
                >
                  <social.icon className="h-5 w-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Footer links */}
          {footerSections.map((section, index) => (
            <div key={index}>
              <h4 className="text-lg font-semibold mb-4">{section.title}</h4>
              <ul className="space-y-3">
                {section.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <a
                      href="#"
                      className="text-gray-300 hover:text-emerald-400 transition-colors duration-200 text-sm"
                    >
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="text-sm text-gray-400">
              © 2024 Brown Living. All rights reserved.
            </div>
            <div className="flex flex-wrap gap-6 text-sm">
              <span className="text-gray-400">🇮🇳 Made in India</span>
              <span className="text-gray-400">🌱 Carbon Neutral Shipping</span>
              <span className="text-gray-400">♻️ Plastic Free Packaging</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;