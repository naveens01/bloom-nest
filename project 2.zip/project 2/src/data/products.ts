export interface Product {
  id: number;
  name: string;
  brand: string;
  price: number;
  originalPrice: number;
  image: string;
  rating: number;
  reviews: number;
  badge?: string;
  description?: string;
  category: string;
}

export const products: Product[] = [
  // Personal Care Products
  {
    id: 1,
    name: 'Organic Bamboo Toothbrush Set',
    brand: 'EcoSmile',
    price: 399,
    originalPrice: 499,
    image: 'https://images.pexels.com/photos/6621464/pexels-photo-6621464.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.8,
    reviews: 127,
    badge: 'Bestseller',
    description: 'Biodegradable bamboo toothbrush with soft bristles',
    category: 'Personal Care'
  },
  {
    id: 2,
    name: 'Natural Face Wash with Neem',
    brand: 'PureGlow',
    price: 299,
    originalPrice: 350,
    image: 'https://images.pexels.com/photos/7656738/pexels-photo-7656738.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.6,
    reviews: 89,
    badge: 'New',
    description: 'Gentle face wash with natural neem extract',
    category: 'Personal Care'
  },
  {
    id: 3,
    name: 'Handmade Soap Collection',
    brand: 'NaturalCare',
    price: 599,
    originalPrice: 750,
    image: 'https://images.pexels.com/photos/4202325/pexels-photo-4202325.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.5,
    reviews: 94,
    badge: 'Sale',
    description: 'Set of 4 handmade soaps with natural ingredients',
    category: 'Personal Care'
  },
  {
    id: 4,
    name: 'Organic Shampoo Bar',
    brand: 'EcoHair',
    price: 450,
    originalPrice: 550,
    image: 'https://images.pexels.com/photos/3762875/pexels-photo-3762875.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.7,
    reviews: 156,
    description: 'Zero-waste shampoo bar for all hair types',
    category: 'Personal Care'
  },
  {
    id: 5,
    name: 'Natural Deodorant Stick',
    brand: 'FreshNature',
    price: 350,
    originalPrice: 420,
    image: 'https://images.pexels.com/photos/7656738/pexels-photo-7656738.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.4,
    reviews: 78,
    description: 'Aluminum-free natural deodorant with essential oils',
    category: 'Personal Care'
  },
  {
    id: 6,
    name: 'Organic Lip Balm Set',
    brand: 'LipCare',
    price: 250,
    originalPrice: 300,
    image: 'https://images.pexels.com/photos/4202325/pexels-photo-4202325.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.6,
    reviews: 92,
    description: 'Set of 3 organic lip balms with different flavors',
    category: 'Personal Care'
  },

  // Home & Living Products
  {
    id: 7,
    name: 'Reusable Cotton Bags Set',
    brand: 'GreenHome',
    price: 799,
    originalPrice: 999,
    image: 'https://images.pexels.com/photos/6207833/pexels-photo-6207833.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.9,
    reviews: 203,
    badge: 'Popular',
    description: 'Set of 5 reusable cotton bags for grocery shopping',
    category: 'Home & Living'
  },
  {
    id: 8,
    name: 'Wooden Kitchen Utensils',
    brand: 'WoodCraft',
    price: 899,
    originalPrice: 1100,
    image: 'https://images.pexels.com/photos/6207833/pexels-photo-6207833.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.8,
    reviews: 178,
    badge: 'Eco-Friendly',
    description: 'Set of 6 handcrafted wooden kitchen utensils',
    category: 'Home & Living'
  },
  {
    id: 9,
    name: 'Bamboo Storage Containers',
    brand: 'EcoStore',
    price: 1299,
    originalPrice: 1599,
    image: 'https://images.pexels.com/photos/6207833/pexels-photo-6207833.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.7,
    reviews: 145,
    description: 'Set of 4 bamboo containers with airtight lids',
    category: 'Home & Living'
  },
  {
    id: 10,
    name: 'Organic Cotton Bedsheets',
    brand: 'SleepWell',
    price: 2499,
    originalPrice: 3200,
    image: 'https://images.pexels.com/photos/6207833/pexels-photo-6207833.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.6,
    reviews: 89,
    description: 'Soft organic cotton bedsheet set with pillowcases',
    category: 'Home & Living'
  },
  {
    id: 11,
    name: 'Jute Table Runner',
    brand: 'NaturalDecor',
    price: 599,
    originalPrice: 750,
    image: 'https://images.pexels.com/photos/6207833/pexels-photo-6207833.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.5,
    reviews: 67,
    description: 'Handwoven jute table runner with decorative border',
    category: 'Home & Living'
  },
  {
    id: 12,
    name: 'Coconut Coir Doormat',
    brand: 'EcoMat',
    price: 799,
    originalPrice: 950,
    image: 'https://images.pexels.com/photos/6207833/pexels-photo-6207833.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.8,
    reviews: 134,
    description: 'Natural coconut coir doormat with custom design',
    category: 'Home & Living'
  },

  // Fashion Products
  {
    id: 13,
    name: 'Organic Cotton T-Shirt',
    brand: 'EcoWear',
    price: 899,
    originalPrice: 1200,
    image: 'https://images.pexels.com/photos/7679720/pexels-photo-7679720.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.7,
    reviews: 156,
    badge: 'Trending',
    description: 'Soft organic cotton t-shirt in various colors',
    category: 'Fashion'
  },
  {
    id: 14,
    name: 'Hemp Canvas Tote Bag',
    brand: 'GreenFashion',
    price: 1299,
    originalPrice: 1599,
    image: 'https://images.pexels.com/photos/7679720/pexels-photo-7679720.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.6,
    reviews: 98,
    description: 'Durable hemp canvas tote bag with leather handles',
    category: 'Fashion'
  },
  {
    id: 15,
    name: 'Bamboo Fiber Socks',
    brand: 'ComfortFeet',
    price: 499,
    originalPrice: 650,
    image: 'https://images.pexels.com/photos/7679720/pexels-photo-7679720.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.5,
    reviews: 87,
    description: 'Antibacterial bamboo fiber socks - pack of 3',
    category: 'Fashion'
  },
  {
    id: 16,
    name: 'Organic Cotton Dress',
    brand: 'NaturalStyle',
    price: 2499,
    originalPrice: 3200,
    image: 'https://images.pexels.com/photos/7679720/pexels-photo-7679720.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.8,
    reviews: 124,
    description: 'Elegant organic cotton dress with natural dyes',
    category: 'Fashion'
  },
  {
    id: 17,
    name: 'Recycled Denim Jacket',
    brand: 'EcoJeans',
    price: 3499,
    originalPrice: 4500,
    image: 'https://images.pexels.com/photos/7679720/pexels-photo-7679720.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.7,
    reviews: 76,
    description: 'Stylish jacket made from recycled denim',
    category: 'Fashion'
  },
  {
    id: 18,
    name: 'Linen Palazzo Pants',
    brand: 'LinenLove',
    price: 1899,
    originalPrice: 2400,
    image: 'https://images.pexels.com/photos/7679720/pexels-photo-7679720.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.6,
    reviews: 103,
    description: 'Comfortable linen palazzo pants for summer',
    category: 'Fashion'
  },

  // Wellness Products
  {
    id: 19,
    name: 'Organic Tea Collection',
    brand: 'TeaGarden',
    price: 1299,
    originalPrice: 1500,
    image: 'https://images.pexels.com/photos/1389104/pexels-photo-1389104.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.7,
    reviews: 156,
    badge: 'Limited',
    description: 'Premium collection of 6 organic herbal teas',
    category: 'Wellness'
  },
  {
    id: 20,
    name: 'Yoga Mat - Cork & Rubber',
    brand: 'ZenYoga',
    price: 2499,
    originalPrice: 3200,
    image: 'https://images.pexels.com/photos/3766227/pexels-photo-3766227.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.8,
    reviews: 189,
    description: 'Eco-friendly yoga mat made from cork and natural rubber',
    category: 'Wellness'
  },
  {
    id: 21,
    name: 'Essential Oil Diffuser',
    brand: 'AromaLife',
    price: 1899,
    originalPrice: 2400,
    image: 'https://images.pexels.com/photos/3766227/pexels-photo-3766227.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.6,
    reviews: 134,
    description: 'Ultrasonic essential oil diffuser with LED lights',
    category: 'Wellness'
  },
  {
    id: 22,
    name: 'Meditation Cushion',
    brand: 'MindfulSit',
    price: 1599,
    originalPrice: 2000,
    image: 'https://images.pexels.com/photos/3766227/pexels-photo-3766227.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.7,
    reviews: 98,
    description: 'Organic buckwheat hull meditation cushion',
    category: 'Wellness'
  },
  {
    id: 23,
    name: 'Herbal Sleep Tea',
    brand: 'DreamTea',
    price: 599,
    originalPrice: 750,
    image: 'https://images.pexels.com/photos/1389104/pexels-photo-1389104.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.5,
    reviews: 87,
    description: 'Calming herbal tea blend for better sleep',
    category: 'Wellness'
  },
  {
    id: 24,
    name: 'Natural Protein Powder',
    brand: 'PlantPower',
    price: 2299,
    originalPrice: 2800,
    image: 'https://images.pexels.com/photos/3766227/pexels-photo-3766227.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.6,
    reviews: 145,
    description: 'Plant-based protein powder with superfoods',
    category: 'Wellness'
  }
];

export const getProductsByCategory = (category: string): Product[] => {
  return products.filter(product => product.category === category);
};

export const getFeaturedProducts = (): Product[] => {
  return products.slice(0, 6);
};